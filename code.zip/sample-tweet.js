tweet:{
   created_at:'Sun Oct 16 20:37:39 +0000 2016',
   id:787754401695957000,
   id_str:'787754401695956996',
   text:'Hot sake Sunday come join us for lunch or dinner and enjoy a small craft of hot sake which will… https://t.co/DUwjvgg0z4',
   source:'<a href="http://instagram.com" rel="nofollow">Instagram</a>',
   truncated:false,
   in_reply_to_status_id:null,
   in_reply_to_status_id_str:null,
   in_reply_to_user_id:null,
   in_reply_to_user_id_str:null,
   in_reply_to_screen_name:null,
   user:{
      id:855333542,
      id_str:'855333542',
      name:'Anikis-Sushi',
      screen_name:'Anikis_Sushi',
      location:null,
      url:null,
      description:'Aniki\'s Sushi in Fremont, CA',
      protected:false,
      verified:false,
      followers_count:146,
      friends_count:39,
      listed_count:14,
      favourites_count:228,
      statuses_count:4354,
      created_at:'Sun Sep 30 20:47:36 +0000 2012',
      utc_offset:-25200,
      time_zone:'Pacific Time (US & Canada)',
      geo_enabled:true,
      lang:'en',
      contributors_enabled:false,
      is_translator:false,
      profile_background_color:'C3EBCD',
      profile_background_image_url:'http://pbs.twimg.com/profile_background_images/687236248/ebb6b612a88df3d5023b15f77af465ad.jpeg',
      profile_background_image_url_https:'https://pbs.twimg.com/profile_background_images/687236248/ebb6b612a88df3d5023b15f77af465ad.jpeg',
      profile_background_tile:false,
      profile_link_color:'00B377',
      profile_sidebar_border_color:'FFFFFF',
      profile_sidebar_fill_color:'DDEEF6',
      profile_text_color:'333333',
      profile_use_background_image:true,
      profile_image_url:'http://pbs.twimg.com/profile_images/2667175011/e0c1424c570bb579e3a0af69859ee1fd_normal.jpeg',
      profile_image_url_https:'https://pbs.twimg.com/profile_images/2667175011/e0c1424c570bb579e3a0af69859ee1fd_normal.jpeg',
      default_profile:false,
      default_profile_image:false,
      following:null,
      follow_request_sent:null,
      notifications:null
   },
   geo:{
      type:'Point',
      coordinates:[
         37.54951093,
         -121.98647222
      ]
   },
   coordinates:{
      type:'Point',
      coordinates:[
         -121.98647222,
         37.54951093
      ]
   },
   place:{
      id:'30344aecffe6a491',
      url:'https://api.twitter.com/1.1/geo/id/30344aecffe6a491.json',
      place_type:'city',
      name:'Fremont',
      full_name:'Fremont, CA',
      country_code:'US',
      country:'United States',
      bounding_box:{
         type:'Polygon',
         coordinates:[
            Object
         ]
      },
      attributes:{

      }
   },
   contributors:null,
   is_quote_status:false,
   retweet_count:0,
   favorite_count:0,
   entities:{
      hashtags:[

      ],
      urls:[
         [
            Object
         ]
      ],
      user_mentions:[

      ],
      symbols:[

      ]
   },
   favorited:false,
   retweeted:false,
   possibly_sensitive:false,
   filter_level:'low',
   lang:'en',
   timestamp_ms:'1476650259790'
}


"hits":{
  "_index": "tweets2",
  "_type": "tweets",
  "_id": "AVfbPEpepOSx-C9TowaU",
  "_score": 1,
  "_source": {
     "tweetGeoCoordinates": [
        36.0252914,
        -83.9897614
     ],
     "tweetContent": "Playing around with a new door design. @ Nymbis Vapors https://t.co/NrfRkJ8Kcu"
  }
}
