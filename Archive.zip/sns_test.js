var fs = require('fs');
var nconf = require('nconf');
nconf.file({ file: 'config.json' }).env();

var AWS = require('aws-sdk');
AWS.config.update({accessKeyId: nconf.get('ACCESS_KEY_ID'), secretAccessKey: nconf.get('SECRECT_ACCESS_KEY')});
var sns = new AWS.SNS({region:nconf.get('REGION')}); 

var params = {
  Protocol: 'http', /* required */
  TopicArn: 'arn:aws:sns:us-east-1:236141017744:twitterMapTopic', /* required */
  Endpoint: 'http://localhost:8080/'
};
sns.subscribe(params, function(err, data) {
  if (err) console.log(err, err.stack); // an error occurred
  else     console.log(data);           // successful response
});
